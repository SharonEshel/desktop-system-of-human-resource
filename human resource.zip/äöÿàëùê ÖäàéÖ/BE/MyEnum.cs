﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public enum Gender { female, male }
    public enum DomainName { databases, communication, dataSecurity, ServerSideProgramming, mobileProgramming, userInterfaceDesign };
    public enum Degree { diploma, BA, MA, PHD, student }
    public enum Location { north, south, center, plain }


}
