﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public class BankAccount
    {
        
        
        public string Account;
       // public Branch BankBranch;
        //public int BankNumber;
        public string BankName;
        public string NumBankBranch;//סניף בנק
        public string BankAddress;
        public string BankCity;



        public override string ToString()
        {
            return //"\nBank Number: " + BankNumber +
                " \nBank Name: " + BankName +
                //" \nBank Branch's Number:" + NumBankBranch +
                " \nBank Adress:" + BankAddress +
                " \nBank City:" + BankCity+
                "\nAccount Number:" + Account + "\n";

        }
    }


}
