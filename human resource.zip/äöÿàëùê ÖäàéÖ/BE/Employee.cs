﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
   public class Employee
    {
        public Gender EmployeeGender
        {
            get;
            set;
        }
        public bool IsMarried
        {
            get;
            set;
        }
        public BE.Location EmployeeLocation
        {
            get;
            set;
        }
        public string Id
        {
            get;
            set;
            
            //{
            //    try
            //    {
            //        if (value > 0)
            //            Id = value;
            //        else throw new ArgumentException("The number must be positive");

            //    }
            //    catch (Exception ex)
            //    {
            //        Console.WriteLine(ex.Message);
            //    }
            //}
        }


        public string LastName
        {
            get;
            set;
        }

        public string FirstName
        {
            get;
            set;
        }

        public int YearsOfExperience
        {
            get;
            set;
        }

        public DateTime BirthDate
        {
            get;
            set;
            //{

            //    try
            //    {
            //        if (value.Month > 0 && value.Month <= 12 && value.Year < 2016 && value.Day >= 1 && value.Day <= 31)
            //            BirthDate = value;
            //        else throw new ArgumentException("incorrect date\n");

            //    }
            //    catch (Exception ex)
            //    {
            //        Console.WriteLine(ex.Message);
            //    }
            //}

        }

        public string PhoneNumber
        {
            get;
            set;
        }

        public string adress
        {
            get;
            set;
        }

        public Degree _Degree
        {
            get;
            set;

        }
        public bool IsArmy
        {
            get;
            set;
        }

        public BankAccount bank
        {
            get;
            set;
        }

        public int SpecializationIdentify
        {
            get;
            set;
            //{
            //    try
            //    {
            //        if (value >= 10000000)
            //            SpecializationIdentify = value;
            //        else throw new ArgumentException("The number must has 8 digits");

            //    }
            //    catch (Exception ex)
            //    {
            //        Console.WriteLine(ex.Message);
            //    }


            //}
        }
        public override string ToString()
        {
            return "\nID: " + Id +
                "  Last Name: " + LastName +
                "  First Name " + FirstName +
                "  Birth Date: " + BirthDate.ToShortDateString() +
                "  Phone Number: " + PhoneNumber +
                "  Adress: " + adress +
                "  Degree: " + _Degree +
                "  Served In Army: " + IsArmy +
                   bank.ToString() +
               " Specialization Identify: " + SpecializationIdentify + "\n";
        }
    }
}
