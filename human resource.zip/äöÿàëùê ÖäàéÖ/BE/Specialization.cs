﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public class Specialization
    {
        public static int specialCounter = 10000000;
        public int NumSpecialization
        {
            get;
            set;
        }

        public BE.DomainName Domain_Name
        {
            get;
            set;
        }

        public string SpecializationName
        {
            get;
            set;

        }

        public double MinimumRate
        {
            get;
            set;
            //    //if the rate is negative or zero throw an exeption
            //{
            //    try
            //    {
            //        if (value > 0)
            //            MinimumRate = value;
            //        else throw new ArgumentException("The number must be positive");

            //    }
            //    catch (Exception ex)
            //    {
            //        Console.WriteLine(ex.Message);
            //    }

            //}
        }

        public double MaximumRate
        {
            get;
            set;
            //{
            //    try
            //    {
            //        if (value >= MinimumRate)
            //            MaximumRate = value;
            //        else throw new ArgumentException("The number must be bigger than maximum rate");

            //    }
            //    catch (Exception ex)
            //    {
            //        Console.WriteLine(ex.Message);
            //    }

            //}
        }
        public override string ToString()
        {
            return "\nSpecialization number: " + NumSpecialization +
                " \nDomain Name: " + Domain_Name +
                " \nSpecialization Name: " + SpecializationName +
                " \nMinimum rate: " + MinimumRate +
                 " \nMaximum rate: " + MaximumRate + "\n";
        }
    }
}
