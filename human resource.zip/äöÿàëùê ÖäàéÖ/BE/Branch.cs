﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public class Branch
    {
        //public int BankNumber;
        public string BankNumber;
        public string BankName;
        //public int NumBankBranch;//סניף בנק
        public string NumBankBranch;
        public string BankAddress;
        public string BankCity;

        public override string ToString()
        {
            return "\nBank Number: " + BankNumber +
                " \nBank Name: " + BankName +
                " \nBank Branch's Number:" + NumBankBranch +
                " \nBank Adress:" + BankAddress +
                " \nBank CityL:" + BankCity + "\n";

        }
    }
}
