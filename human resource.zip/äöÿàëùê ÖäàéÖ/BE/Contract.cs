﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public class Contract
    {

        public static int countContract = 10000000;
        public int ContractNum
        {
            get;
            set;
        }

        public string EmployerNum
        {
            get;
            set;
        }

        public string EmployeeId
        {
            get;
            set;
        }

        public bool Interview
        {
            get;
            set;
        }

        public bool SigningDeal//האם נחתם עסקה
        {
            get;
            set;
        }

        public double GrossSalaryPerHour
        {
            get;
            set;
            //{
            //    try
            //    {
            //        if (value > 0)
            //            GrossSalaryPerHour = value;
            //        else throw new ArgumentException("Salary  must be positive");

            //    }
            //    catch (Exception ex)
            //    {
            //        Console.WriteLine(ex.Message);
            //    }


            //}
        }

        public double NetoSalaryPerHour
        {
            get;
            set;
            //{
            //    try
            //    {
            //        if (value > 0 && value <= GrossSalaryPerHour)
            //            NetoSalaryPerHour = value;
            //        else throw new ArgumentException("Salary must be positive and smaller than the gross salary");

            //    }
            //    catch (Exception ex)
            //    {
            //        Console.WriteLine(ex.Message);
            //    }


            //}
        }

        public DateTime ContractBeginDate
        {
            get;
            set;
            //{

            //    try
            //    {
            //        if (value.Month > 0 && value.Month <= 12 && value.Year < 2016 && value.Day >= 1 && value.Day <= 31)
            //            ContractBeginDate = value;
            //        else throw new ArgumentException("incorrect date\n");

            //    }
            //    catch (Exception ex)
            //    {
            //        Console.WriteLine(ex.Message);
            //    }
            //}

        }

        public DateTime ContractEndDate
        {
            get;
            set;
            //{

            //    try
            //    {
            //        if (value.Month > 0 && value.Month <= 12 && value.Year < 2016 && value.Day >= 1 && value.Day <= 31)
            //            ContractEndDate = value;
            //        else throw new ArgumentException("incorrect date\n");

            //    }
            //    catch (Exception ex)
            //    {
            //        Console.WriteLine(ex.Message);
            //    }
            //}

        }

        public double HourDeal
        {
            get;
            set;
            //    //if hour's number is negative or zero throw an exeption
            //{
            //    try
            //    {
            //        if (value > 0)
            //            HourDeal = value;
            //        else throw new ArgumentException("hour's number must be positive\n");

            //    }
            //    catch (Exception ex)
            //    {
            //        Console.WriteLine(ex.Message);
            //    }

            //}


        }

        public override string ToString()
        {
            return "\nContract Number: " + ContractNum +
                "  Employer Nummber: " + EmployerNum +
                "  Employee Number: " + EmployeeId +
                "  Was an Interview: " + Interview +
                "  Signing a Deal: " + SigningDeal +
                "  Gross Salary Per Hour: " + GrossSalaryPerHour +
                "  Neto Salary Per Hour: " + NetoSalaryPerHour +
                "  Contract Begin Date: " + ContractBeginDate.ToShortDateString() +
                "  Contract End Date: " + ContractEndDate.ToShortDateString() +
                "  Deal's Hours: " + HourDeal + "\n";
        }

    }

}
