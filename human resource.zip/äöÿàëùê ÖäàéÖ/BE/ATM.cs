﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public class ATM
    {
        public int BankCode { get; set; }
        public string BankName { get; set; }

        public int ATMCode { get; set; }
        public string ATMAddress { get; set; }
        public string City { get; set; }

    }
}


