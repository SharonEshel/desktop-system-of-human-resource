﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
   public class Employer
    {
        public BE.Location EmployerLocation
        {
            get;
            set;
        }
        public string NumCompany
        {
            get;
            set;
        }
        //return true if it is private,else(company) return false
        public bool IsPrivate
        {
            get;
            set;
        }

        public string LastName
        {
            get;
            set;
        }

        public string FirstName
        {
            get;
            set;
        }

        public string CompanyName
        {
            get;
            set;
            ////if the company is private there isn't a name
            //{
            //    if (!IsPrivate)
            //        CompanyName = value;
            //}
        }

        public string PhoneNumber
        {
            get;
            set;
        }

        public string Address
        {
            get;
            set;
        }

        public DomainName Domain_Name
        {
            get;
            //{
            //    return Domain_Name;
            //}
            set;/* { Domain_Name = value; }*/
        }

        public DateTime EstablishmentDate
        {
            get;
            set;
            //{

            //    try
            //    {
            //        if (value.Month > 0 && value.Month <= 12 && value.Year < 2016 && value.Day >= 1 && value.Day <= 31)
            //            EstablishmentDate = value;
            //        else throw new ArgumentException("incorrect date\n");

            //    }
            //    catch (Exception ex)
            //    {
            //        Console.WriteLine(ex.Message);
            //    }
            //}

        }

        public override string ToString()
        {
            string s =
             "\nCompany Number: " + NumCompany +
                " \nA Private Employer: " + IsPrivate +
                " \nEmployer's Last Name: " + LastName +
                " \nEmployer's First Name: " + FirstName;
            //there is a name only if it is a company
            if (!IsPrivate)
            {
                s += " \nCompany's Name: " + CompanyName;

            }
            return s + " \nPhone Number: " + PhoneNumber +
                " \nEmloyer's Address: " + Address +
                " \nEmployment Domain: " + Domain_Name +
                " \nEstablishment Date: " + EstablishmentDate.ToShortDateString();
        }
    }
}
