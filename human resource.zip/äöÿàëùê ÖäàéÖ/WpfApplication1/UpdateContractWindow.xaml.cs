﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BE;
namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for UpdateContractWindow.xaml
    /// </summary>
    public partial class UpdateContractWindow : Window
    {
        Contract con;
        BL.IBL bl;
        public UpdateContractWindow()
        {
            
            InitializeComponent();
            con = new Contract();
            con.ContractBeginDate = DateTime.Now;
            con.ContractEndDate = DateTime.Now;
            this.DataContext = con;
            bl = BL.FactoryBL.GetBL();
            this.ContractNumComboBox.ItemsSource = from c in bl.GetAllContract()
                                                   select c.ContractNum;
            this.EmployeeIdNumberComboBox.ItemsSource = from s in bl.GetAllEmployee()
                                                        select s.Id;
            this.EmployerNumComboBox.ItemsSource = from s in bl.GetAllEmployer()
                                                   select s.NumCompany;
            this.ContractBeginDateDatePicker.SelectedDate = DateTime.Now;
        }

        private void ContractNumComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Contract co= bl.GetContract(con.ContractNum);
            if (con != null)
                con = co;
            DataContext = con;
            this.ContractNumComboBox.IsEnabled = false;
        }

        private void EmployerNumComboBox_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {

        }

        private void updateButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                bl.UpdateContract(con);


                con = new Contract();
                this.DataContext = con;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }
    }
}
