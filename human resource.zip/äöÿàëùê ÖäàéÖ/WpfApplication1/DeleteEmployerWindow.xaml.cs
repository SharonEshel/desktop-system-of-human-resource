﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BE;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for DeleteEmployerWindow.xaml
    /// </summary>
    public partial class DeleteEmployerWindow : Window
    {
        BL.IBL bl;
        Employer em;
        public DeleteEmployerWindow()
        {
            InitializeComponent();
            em = new Employer();
            this.DataContext = em;
            bl = BL.FactoryBL.GetBL();
            this.NumCompanyComboBox.ItemsSource = from s in bl.GetAllEmployer()
                                                  select s.NumCompany;
        }

        private void deleteButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bl.GetEmployer(em.NumCompany);
                bl.DeleteEmployer(em.NumCompany);

                em = new BE.Employer();
                this.DataContext = em;
                this.NumCompanyComboBox.ItemsSource = from s in bl.GetAllEmployer()
                                                      select s.NumCompany;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void EmployerNumComboBox_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
