﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BE;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for DeleteEmployeeWindow.xaml
    /// </summary>
    public partial class DeleteEmployeeWindow : Window
    {
        BL.IBL bl;
        Employee em;
        public DeleteEmployeeWindow()
        {
            InitializeComponent();
            em = new Employee();
            this.DataContext = em;
            bl = BL.FactoryBL.GetBL();
            this.IdComboBox.ItemsSource = from s in bl.GetAllEmployee()
                                          select s.Id;
        }

        private void EmployerNumComboBox_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {

        }

        private void deleteButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bl.GetEmployee(em.Id);
                bl.DeleteEmployee(em.Id);

                em = new BE.Employee();
                this.DataContext = em;
                this.IdComboBox.ItemsSource = from s in bl.GetAllEmployee()
                                              select s.Id;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
