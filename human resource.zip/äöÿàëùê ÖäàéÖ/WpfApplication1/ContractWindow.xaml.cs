﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for ContractWindow.xaml
    /// </summary>
    public partial class ContractWindow : Window
    {
        public ContractWindow()
        {
            InitializeComponent();
        }
        private void AddContractButton_Click(object sender, RoutedEventArgs e)
        {
            new AddContractWindow().Show();
            this.Close();
        }

        private void UpdateContractButton_Click(object sender, RoutedEventArgs e)
        {
            new UpdateContractWindow().Show();
            this.Close();
        }


        private void DeleteContractButton_Click(object sender, RoutedEventArgs e)
        {
            new DeleteContractWindow().Show();
            this.Close();
        }
    }
}
