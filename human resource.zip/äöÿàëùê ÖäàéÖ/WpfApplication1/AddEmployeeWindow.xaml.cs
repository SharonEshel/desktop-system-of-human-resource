﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BE;


namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for AddEmployeeWindow.xaml
    /// </summary>
    public partial class AddEmployeeWindow : Window
    {
        BL.IBL bl;
        Employee em;
        public AddEmployeeWindow()
        {
            InitializeComponent();
            em = new Employee();
            em.bank = new BankAccount();
            em.BirthDate= DateTime.Now;
            this.DataContext = em;
            bl = BL.FactoryBL.GetBL();
            this.employeeGenderComboBox.ItemsSource = Enum.GetValues(typeof(BE.Gender));
            this.employeeLocationComboBox.ItemsSource = Enum.GetValues(typeof(BE.Location));
            this.employeeDegreeComboBox.ItemsSource = Enum.GetValues(typeof(BE.Degree));
            this.SpecializationIdentifyComboBox.ItemsSource = from s in bl.GetAllSpecialization()
                                                              select s.NumSpecialization;
            this.employeeBirthdayDateDatePicker.SelectedDate = DateTime.Now;



        }

        private void SpecializationIdentifyComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void addButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                em.bank.Account = numAccountTextBox.Text;
                bl.AddEmployee(em);
                //em = new BE.Employee();
                //this.DataContext = em;
                this.Close();
                if (em.YearsOfExperience == 0)
                {
                    
                    throw new Exception("0 years of experience");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
                

            }

        }

        private void employeeAdressTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void employeePhoneNumberTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void AddDetailsOfBank_Click(object sender, RoutedEventArgs e)
        {
            BankWindow bank = new BankWindow(this,em);
            bank.Show();

        }

        
    }

}
