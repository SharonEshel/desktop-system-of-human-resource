﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BE;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for AdditionalFunctionWindow.xaml
    /// </summary>
    public partial class AdditionalFunctionWindow : Window
    {
        BL.IBL bl;
        Employee employee;
        Employer employer;
        Specialization sp;
        public AdditionalFunctionWindow()
        {
            InitializeComponent();
            employee = new Employee();
            employer = new Employer();
            sp = new Specialization();
            //this.DataContext = employee;
            this.DataContext = employer;
            //  this.DataContext = sp;
            bl = BL.FactoryBL.GetBL();
            this.EmployeeOfSpesificEmployer.ItemsSource = from s in bl.GetAllEmployer()
                                                          select s.NumCompany;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Employer emp = bl.GetEmployer(employer.NumCompany);
            if (bl.EmployeesOfSpesificEmployer(emp) == null || !bl.EmployeesOfSpesificEmployer(emp).Any()) 
                textBlock.Text = "There are not signed employees for this employer";
            else
               textBlock.Text = bl.EmployeeWithMaxSalary(emp).ToString();
            
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            try
            {
                string st = "";
                foreach (Contract s in bl.signContracts())
                {
                    st += s.ToString();
                }

                if (st == "")
                    textBlock.Text = "There are not signed contracts";
                else
                    textBlock.Text = st;
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                
            }

        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {

            string st = "";
            Employer emp = bl.GetEmployer(employer.NumCompany);
            //if (bl.EmployeesOfSpesificEmployer(emp) == null)
            if (bl.EmployeesOfSpesificEmployer(emp) == null || !bl.EmployeesOfSpesificEmployer(emp).Any())
                st = "There are not signed employees for this employer";
            else
            {
                foreach (Employee s in bl.EmployeesOfSpesificEmployer(emp))
                {
                    st += s.ToString();
                }
            }
            textBlock.Text = st;

        }

        private void EmployeeOfSpesificEmployercomboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

    }
}
