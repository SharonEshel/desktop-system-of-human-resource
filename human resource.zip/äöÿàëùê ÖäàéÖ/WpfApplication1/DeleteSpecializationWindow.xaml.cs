﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BE;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for DeleteSpecializationWindow.xaml
    /// </summary>
    public partial class DeleteSpecializationWindow : Window
    {
        BL.IBL bl;
        Specialization sp;
        public DeleteSpecializationWindow()
        {
            InitializeComponent();
            sp = new Specialization();
            this.DataContext = sp;
            bl = BL.FactoryBL.GetBL();
            this.NumSpecializationComboBox.ItemsSource = from s in bl.GetAllSpecialization()
                                                         select s.NumSpecialization;
        }



        private void NumSpecializationComboBox_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {

        }

        private void deleteButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bl.GetSpecialization(sp.NumSpecialization);
                bl.DeleteSpecializationNum(sp.NumSpecialization);

                sp = new BE.Specialization();
                this.DataContext = sp;
                this.NumSpecializationComboBox.ItemsSource = from s in bl.GetAllSpecialization()
                                                             select s.NumSpecialization;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
