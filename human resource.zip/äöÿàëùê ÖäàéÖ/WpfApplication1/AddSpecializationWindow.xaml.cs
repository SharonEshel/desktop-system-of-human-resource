﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BE;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for AddSpecializationWindow.xaml
    /// </summary>
    public partial class AddSpecializationWindow : Window
    {
        BL.IBL bl;
        Specialization new_specialization;
        public AddSpecializationWindow()
        {
            InitializeComponent();
            new_specialization = new Specialization();
            this.DataContext = new_specialization;
            bl = BL.FactoryBL.GetBL();
            this.DomainNameComboBox.ItemsSource = Enum.GetValues(typeof(BE.DomainName));
            
        }

        private void DomainNameComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void SpecializationNameTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void MinimumRateTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void MaximumRateTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void addButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bl.AddSpecialization(new_specialization);
                this.Close();
                throw new Exception("specialization num is: " + new_specialization.NumSpecialization);
                
             
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                
            }
        }
    }
}
