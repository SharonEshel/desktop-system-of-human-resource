﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BE;
using System.ComponentModel;



namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for BankWindow.xaml
    /// </summary>
    public partial class BankWindow : Window
    {
        BL.IBL bl;
        BankAccount ba;
        Employee employee;
        private readonly BackgroundWorker worker = new BackgroundWorker();
        IEnumerable<IGrouping<string, IGrouping<string, ATM>>> banks;
        private AddEmployeeWindow emWindow = null;
        private UpdateEmployeeWindow emUpdateWindow = null;
        public BankWindow()
        {
            bl = BL.FactoryBL.GetBL();
            InitializeComponent();
            worker.DoWork += Worker_DoWork;
            worker.RunWorkerCompleted += Worker_RunWorkerCompleted;
            ba = new BankAccount();
            employee = new Employee();
        }

        public BankWindow(AddEmployeeWindow a,Employee em)
        {
            InitializeComponent();
            bl = BL.FactoryBL.GetBL();
            emWindow = a;// due to save the details in the same employee
            
            ba = new BankAccount();
            this.DataContext = ba;
            employee = em;
            worker.DoWork += Worker_DoWork;//לפי עיר
            worker.RunWorkerCompleted += Worker_RunWorkerCompleted;//לפי עיר לcomboBOX מקשר את רשימת הבנקים 
            this.changeTheChoose.Visibility = Visibility.Hidden;
            //ba = new BankAccount();
            //this.DataContext = ba;
            //employee = em;


        }
        public BankWindow(UpdateEmployeeWindow a, Employee em)
        {
            InitializeComponent();
            bl = BL.FactoryBL.GetBL();
            emUpdateWindow = a;// due to save the details in the same employee

            ba = new BankAccount();
            this.DataContext = ba;
            employee = em;
            this.SaveTheChoose.Visibility = Visibility.Hidden;
            worker.DoWork += Worker_DoWork;
            worker.RunWorkerCompleted += Worker_RunWorkerCompleted;
            //ba = new BankAccount();
            //this.DataContext = ba;
            //employee = em;


        }

        private void Worker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            this.bankComboBox.ItemsSource = banks;
            this.bankComboBox.DisplayMemberPath = "Key";
            this.loadButton.IsEnabled = true;
        }

        private void Worker_DoWork(object sender, DoWorkEventArgs e)
        {
            banks = BL.BL.GetAllAtmGroupByBankAndCity().ToList();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            this.loadButton.IsEnabled = false;
            worker.RunWorkerAsync();
        }

        private void SaveTheChoose_Click(object sender, RoutedEventArgs e)
        {
            ba.BankName= bankComboBox.Text;
            ba.BankCity= CityComboBox.Text;
            ba.BankAddress = AdressLabel.Content.ToString();
            //ba.NumBankBranch = AddressComboBox.Text;
            ba.NumBankBranch = ((BE.ATM)AddressComboBox.Items.CurrentItem).ATMCode.ToString();
            employee.bank = ba;


            this.emWindow.BankNameTextBox.Text = bankComboBox.Text;
            this.emWindow.NumBankBranchTextBox.Text = ((BE.ATM)AddressComboBox.Items.CurrentItem).ATMCode.ToString();
            this.emWindow.BankCityTextBox.Text = CityComboBox.Text;
            this.emWindow.BankAddressTextBox.Text = AdressLabel.Content.ToString();
            this.Close();
            
        }

        private void changeTheChoose_Click(object sender, RoutedEventArgs e)
        {
            ba.BankName = bankComboBox.Text;
            ba.BankCity = CityComboBox.Text;
            ba.BankAddress = AdressLabel.Content.ToString();
            ba.NumBankBranch = AddressComboBox.Text;

            employee.bank = ba;


            this.emUpdateWindow.BankNameTextBox.Text = bankComboBox.Text;
            this.emUpdateWindow.NumBankBranchTextBox.Text = AddressComboBox.Text;
            this.emUpdateWindow.BankCityTextBox.Text = CityComboBox.Text;
            this.emUpdateWindow.BankAddressTextBox.Text = AdressLabel.Content.ToString();
            this.Close();
        }
    }
}

