﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for EmployerWindow.xaml
    /// </summary>
    public partial class EmployerWindow : Window
    {
        public EmployerWindow()
        {
            InitializeComponent();
        }
        private void AddEmployerButton_Click(object sender, RoutedEventArgs e)
        {
            new AddEmployerWindow().Show();
            this.Close();
        }

        private void UpdateEmployerButton_Click(object sender, RoutedEventArgs e)
        {
            new UpdateEmployerWindow().Show();
            this.Close();
        }


        private void DeleteEmployerButton_Click(object sender, RoutedEventArgs e)
        {
            new DeleteEmployerWindow().Show();
            this.Close();
        }
    }
}
