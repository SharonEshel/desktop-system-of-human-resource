﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BE;



namespace WpfApplication1
{

    /// <summary>
    /// Interaction logic for AddContractWindow.xaml
    /// </summary>
    public partial class AddContractWindow : Window
    {
        BL.IBL bl;
        Contract con;
        public AddContractWindow()
        {
            InitializeComponent();
            con = new Contract();
            con.ContractBeginDate = DateTime.Now;
            con.ContractEndDate = DateTime.Now;
            this.DataContext = con;
            bl = BL.FactoryBL.GetBL();
            this.EmployeeIdNumberComboBox.ItemsSource = from s in bl.GetAllEmployee()
                                                        select s.Id;
            this.EmployerNumComboBox.ItemsSource = from s in bl.GetAllEmployer()
                                                   select s.NumCompany;
            this.ContractBeginDateDatePicker.SelectedDate = DateTime.Now;
        }

        private void EmployerNumComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void EmployerNumComboBox_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {

        }

        private void addButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bl.AddContract(con);
                //con = new BE.Contract();
                //this.DataContext = con;
                this.Close();
                throw new Exception("The Neto Salary Of The Employee is " + con.NetoSalaryPerHour + "\n" + "The Contract Number Is Set To: " + con.ContractNum);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GrossSalaryPerHourTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}

