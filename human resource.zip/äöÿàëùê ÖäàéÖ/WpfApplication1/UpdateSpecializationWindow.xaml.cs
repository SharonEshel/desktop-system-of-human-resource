﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BE;
namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for UpdateSpecializationWindow.xaml
    /// </summary>
    public partial class UpdateSpecializationWindow : Window
    {
        Specialization sp;
        BL.IBL bl;
        public UpdateSpecializationWindow()
        {
            InitializeComponent();
            sp = new Specialization();
            this.DataContext = sp;
            bl = BL.FactoryBL.GetBL();
            this.DomainNameComboBox.ItemsSource = Enum.GetValues(typeof(BE.DomainName));
            this.NumSpecializationComboBox.ItemsSource = from s in bl.GetAllSpecialization()
                                                         select s.NumSpecialization;

        }

        private void DomainNameComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void SpecializationNameTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void MinimumRateTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void MaximumRateTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void updateButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                bl.UpdateSpecialization(sp);
                if (sp.MaximumRate == 0)
                    throw new Exception("maximum rate is 0");
                if (sp.MinimumRate== 0)
                    throw new Exception("minimum rate is 0");
                //em = new Employee();
                //this.DataContext = em;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        private void NumSpecializationComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Specialization temp = bl.GetSpecialization(sp.NumSpecialization);
            if (temp != null)
                sp = temp;

            DataContext = sp;
            this.NumSpecializationComboBox.IsEnabled = false;
        }
    }
}
