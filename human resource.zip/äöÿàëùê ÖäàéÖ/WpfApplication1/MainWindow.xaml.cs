﻿//Sharon Eshel(Cohen) 206795528, Bareket Baracassa 316033687
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void SpecializationButton_Click(object sender, RoutedEventArgs e)
        {
            new SpecializationWindow().Show();
        }

        private void EmployeeButton_Click(object sender, RoutedEventArgs e)
        {
            new EmployeeWindow().Show();
        }

        private void EmployerButton_Click(object sender, RoutedEventArgs e)
        {
            new EmployerWindow().Show();
        }


        private void ContractButton_Click(object sender, RoutedEventArgs e)
        {
            new ContractWindow().Show();
        }

        private void AdditionalFunctionButton_Click(object sender, RoutedEventArgs e)
        {
            new AdditionalFunctionWindow().Show();
        }
    }
}
