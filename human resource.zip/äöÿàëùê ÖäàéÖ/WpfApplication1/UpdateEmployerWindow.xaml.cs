﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BE;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for UpdateEmployerWindow.xaml
    /// </summary>
    public partial class UpdateEmployerWindow : Window
    {
        Employer emp;
        BL.IBL bl;
        public UpdateEmployerWindow()
        {
            InitializeComponent();
            emp = new Employer();
            emp.EstablishmentDate = DateTime.Now;
            this.DataContext = emp;
            bl = BL.FactoryBL.GetBL();
            this.employerLocationComboBox.ItemsSource = Enum.GetValues(typeof(BE.Location));
            this.Domain_NameComboBox.ItemsSource = Enum.GetValues(typeof(BE.DomainName));
            this.NumCompanyComboBox.ItemsSource= from empp in bl.GetAllEmployer()
                                                 select empp.NumCompany;
        }

       
        private void updateButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                bl.UpdateEmployer(emp);
                emp = new Employer();
                this.DataContext = emp;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        private void NumCompanyComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Employer temp = bl.GetEmployer(emp.NumCompany);
            if (temp != null)
                emp = temp;
            DataContext = emp;
            this.NumCompanyComboBox.IsEnabled = false;
        }

        private void Domain_NameComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void employerLocationComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
