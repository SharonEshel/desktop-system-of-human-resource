﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BE;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for DeleteContractWindow.xaml
    /// </summary>
    public partial class DeleteContractWindow : Window
    {
        BL.IBL bl;
        Contract con;
        public DeleteContractWindow()
        {
            InitializeComponent();
            con = new BE.Contract();
            this.DataContext = con;
            bl = BL.FactoryBL.GetBL();
            this.ContractNumComboBox.ItemsSource = from s in bl.GetAllContract()
                                                   select s.ContractNum;
        }

        private void EmployerNumComboBox_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {

        }

        private void deleteButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // bl.GetContract(con.ContractNum);
                bl.DeleteContract(con.ContractNum);
                con = new BE.Contract();
                this.DataContext = con;
                this.ContractNumComboBox.ItemsSource = from s in bl.GetAllContract()
                                                       select s.ContractNum;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
