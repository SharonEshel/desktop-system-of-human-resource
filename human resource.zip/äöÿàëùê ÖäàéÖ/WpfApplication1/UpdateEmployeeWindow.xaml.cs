﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BE;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for UpdateEmployeeWindow.xaml
    /// </summary>
    public partial class UpdateEmployeeWindow : Window
    {
        Employee em;
        BL.IBL bl;
        public UpdateEmployeeWindow()
        {
            InitializeComponent();
            em = new Employee();
            em.bank = new BankAccount();
            em.BirthDate = DateTime.Now;
            this.DataContext = em;
            bl = BL.FactoryBL.GetBL();
            this.employeeLocationComboBox.ItemsSource = Enum.GetValues(typeof(BE.Location));
            this.employeeGenderComboBox.ItemsSource = Enum.GetValues(typeof(BE.Gender));
            this.employeeDegreeComboBox.ItemsSource = Enum.GetValues(typeof(BE.Degree));
            this.SpecializationIdentifyComboBox.ItemsSource = from s in bl.GetAllSpecialization()
                                                              select s.NumSpecialization;
            this.employeeIdComboBox.ItemsSource = from empp in bl.GetAllEmployee()
                                                  select empp.Id;
            this.employeeBirthdayDateDatePicker.SelectedDate = DateTime.Now;
            
           // EmployeeIdTextBox.LostFocus += EmployeeId_LostFocus;
        }
       

        //private void EmployeeId_LostFocus(object sender, RoutedEventArgs e)
        //{
        //    Employee temp = bl.GetEmployee(em.Id);
        //    if (temp != null)
        //        em = temp;


        //    //employeeDegreeComboBox.Text = em._Degree.ToString();
        //    //employeeGenderComboBox.Text = em.EmployeeGender.ToString();
        //    //SpecializationIdentifyComboBox.Text = em.SpecializationIdentify.ToString();

        //    DataContext = em;
        //}
        private void updateButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                em.bank.Account = numAccountTextBox.Text;
                bl.UpdateEmployee(em);
               
              
                //em = new Employee();
                //this.DataContext = em;
                this.Close();
                if (em.YearsOfExperience == 0)
                {
                    
                    throw new Exception("0 years of experience");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                
            }
        }

        
        private void employeeIdComboBox_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {
            Employee temp = bl.GetEmployee(em.Id);
            if (temp != null)
                em = temp;
            DataContext = em;
            this.employeeIdComboBox.IsEnabled = false;
            this.numAccountTextBox.Text = em.bank.Account;
            this.BankNameTextBox.Text = em.bank.BankName;
            this.NumBankBranchTextBox.Text = em.bank.NumBankBranch;
            this.BankCityTextBox.Text = em.bank.BankCity;
            this.BankAddressTextBox.Text = em.bank.BankAddress;
        }

        private void employeeGenderComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void employeeLocationComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void employeeDegreeComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void SpecializationIdentifyComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void employeeFirstNameTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void employeeLastNameTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void employeePhoneNumberTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void employeeAdressTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void employeeYearsOfExperienceTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        

        private void changeDetailsOfBank_Click(object sender, RoutedEventArgs e)
        {
            BankWindow bank = new BankWindow(this, em);
            bank.Show();
            

        }
    }
    }

