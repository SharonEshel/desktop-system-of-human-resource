﻿/*
Sharon Cohen 206795528
Bareket Baracassa 316033687
*/
/*
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BL;
using BE;

namespace PL
{
    class Program
    {
        static void Main(string[] args)
        {
            BL.BL bl = new BL.BL();
            #region contract
            Contract c = new Contract()
            {
                ContractEndDate = new DateTime(2015, 12, 6),
                SigningDeal = true,
                HourDeal = 23,
                ContractBeginDate = new DateTime(2014, 3, 6),
                EmployerNum = 316033689,
                EmployeeId = 316033688,
                GrossSalaryPerHour = 54,
                NetoSalaryPerHour = 49.6,
                Interview = false
            };

            Contract c1 = new Contract()
            {
                ContractEndDate = new DateTime(2014, 12, 6),
                SigningDeal = false,
                HourDeal = 60,
                ContractBeginDate = new DateTime(2014, 5, 6),
                EmployerNum = 316033680,
                EmployeeId = 316033687,
                GrossSalaryPerHour = 60,
                NetoSalaryPerHour = 54,
                Interview = false
            };

            Contract c2 = new Contract()
            {
                ContractEndDate = new DateTime(2015, 12, 6),
                SigningDeal = false,
                HourDeal = 60,
                ContractBeginDate = new DateTime(1980, 3, 6),
                EmployerNum = 316033689,
                EmployeeId = 316033688,
                GrossSalaryPerHour = 60,
                NetoSalaryPerHour = 54,
                Interview = false
            };

            #endregion
            #region employee
            Employee e = new Employee()
            {
                FirstName = "Sharon",
                LastName = "Eshel",
                adress = "neve",
                IsArmy = false,
                BirthDate = new DateTime(1995, 12, 3),
                Id = 316033688,
                bank = new BankAccount()
                {
                    
                    BankBranch=new Branch()
                    {
                      BankName = "yahav",
                      BankAddress = "shir 5",
                      BankCity = "raanana",
                      NumBankBranch = 118,
                        BankNumber = 4
                    },
                    Account = 123455
                },
                SpecializationIdentify = 10000001,
                PhoneNumber = "0506235639"
            };
            Employee e1 = new Employee()
            {
                FirstName = "Bareket",
                LastName = "Baracassa",
                adress = "neve",
                IsArmy = true,
                BirthDate = new DateTime(1995, 10, 5),
                Id = 316033687,
                bank = new BankAccount()
                {
                    
                    BankBranch = new Branch()
                    {
                        BankName = "yahav",
                        BankAddress = "shir 5",
                        BankCity = "raanana",
                        NumBankBranch = 118,
                        BankNumber = 4
                    },
                    Account = 123458
                },
                SpecializationIdentify = 10000000,
                PhoneNumber = "0506235639"
            };
            #endregion
            #region employer
            Employer emp = new Employer()
            {
                EmployerLocation = Location.center,
                PhoneNumber = "097922356",
                Address = "raanana",
                NumCompany = 316033689,
                FirstName = "thor",
                LastName = "revanue",
                EstablishmentDate = new DateTime(2014, 5, 14),
                IsPrivate = false,
                Domain_Name=DomainName.dataSecurity

            };
            Employer emp1 = new Employer()
            {
                EmployerLocation = Location.center,
                PhoneNumber = "097929356",
                Address = "raanana",
                NumCompany = 316033680,
                FirstName = "shir",
                LastName = "revanue",
                EstablishmentDate = new DateTime(2014, 8, 14),
                IsPrivate = false,
                Domain_Name = DomainName.dataSecurity
            };
            Employer emp2 = new Employer()
            {
                EmployerLocation = Location.north,
                PhoneNumber = "0097929356",
                Address = "raanana",
                NumCompany = 316033680,
                FirstName = "shir",
                LastName = "revanue",
                EstablishmentDate = new DateTime(2014, 8, 14),
                IsPrivate = false,
                Domain_Name = DomainName.dataSecurity
            };
            Employer emp3 = new Employer()
            {
                EmployerLocation = Location.north,
                PhoneNumber = "097929356",
                Address = "raanana",
                NumCompany = 316033685,
                FirstName = "shir",
                LastName = "revanue",
                EstablishmentDate = new DateTime(2014, 8, 14),
                IsPrivate = false,
                Domain_Name = DomainName.dataSecurity
            };
            #endregion
            #region special
            Specialization s = new Specialization()
            {
               // NumSpecialization= 10000009,
                MaximumRate = 60,
                MinimumRate = 30,
                SpecializationName = "data base",
                Domain_Name = DomainName.databases
            };
            Specialization s1 = new Specialization()
            {
                //NumSpecialization = 10000004,
                MaximumRate = 70,
                MinimumRate = 45,
                SpecializationName = "data Security",
                Domain_Name = DomainName.dataSecurity
            };
            #endregion

            ///////////
            try
            {
                bl.AddSpecialization(s);
            }
            catch (Exception exp)
            {
                Console.WriteLine(exp.Message);
            }
            //////////
            try
            {
                bl.AddSpecialization(s);
            }
            catch (Exception exp)
            {
                Console.WriteLine(exp.Message);
            }
            try
            {
                bl.AddSpecialization(s1);
            }
            catch (Exception exp)
            {
                Console.WriteLine(exp.Message);
            }
            ////////////
            try
            {
                bl.AddEmployee(e);
            }
            catch (Exception exp)
            {
                Console.WriteLine(exp.Message);
            }
            /////////////
            try
            {
                bl.AddEmployee(e1);
            }
            catch (Exception exp)
            {
                Console.WriteLine(exp.Message);
            }
            ////////////
            try
            {
                bl.AddEmployer(emp);
            }
            catch (Exception exp)
            {
                Console.WriteLine(exp.Message);
            }
            //////////////
            try
            {
                bl.AddEmployer(emp1);
            }
            catch (Exception exp)
            {
                Console.WriteLine(exp.Message);
            }
            ////////////
            try
            {
                bl.AddEmployer(emp3);
            }
            catch (Exception exp)
            {
                Console.WriteLine(exp.Message);
            }
            ////////////

            try
            {
                bl.AddContract(c);
            }
            catch (Exception exp)
            {
                Console.WriteLine(exp.Message);
            }
            //////////
            try
            {
                bl.AddContract(c1);
            }
            catch (Exception exp)
            {
                Console.WriteLine(exp.Message);
            }
            /////////
            try
            {
                bl.AddContract(c2);
            }
            catch (Exception exp)
            {
                Console.WriteLine(exp.Message);
            }

            var v1 = bl.GetAllSpecialization();
            foreach (Specialization sp in v1)
                Console.WriteLine(sp.ToString());

            var v2 = bl.GetAllEmployee();
            foreach (Employee em in v2)
                Console.WriteLine(em.ToString());

            var v3 = bl.GetAllEmployer();
            foreach (Employer empp in v3)
                Console.WriteLine(empp.ToString());

            var v4 = bl.GetAllContract();
            foreach (Contract cont in v4)
                Console.WriteLine(cont.ToString());

            var help = bl.NumOfContract(con => con.EmployerNum == 316033689);
            Console.WriteLine(help.ToString());
            
            ///////////////////
            try
            {
                bl.UpdateEmployer(emp2);
            }
            catch (Exception exp)
            {
                Console.WriteLine(exp.Message);
            }
            var v5 = bl.GetAllEmployer();
            foreach (Employer empp in v5)
                Console.WriteLine(empp.ToString());
            //////////
            try
            {
                bl.DeleteEmployer(emp3.NumCompany);
            }
            catch (Exception exp)
            {
                Console.WriteLine(exp.Message);
            }
            //////////
            Console.WriteLine("\nlist of employers:\n");
            var v6 = bl.GetAllEmployer();
            foreach (Employer empp in v6)
                Console.WriteLine(empp.ToString());
            /////////igrouping
            Console.WriteLine("\nprouping profits by time:\n");
            var v7 = bl.GroupingProfitbyTime();
            foreach(IGrouping<int, double> item in v7)
                foreach (double profit in item)
                    Console.WriteLine(profit.ToString());

            Console.WriteLine("\nprouping contracts by specialization:\n");
            var v8 = bl.GroupContractBySpecialization();
            foreach (IGrouping<int, Contract> item in v8)
                foreach (Contract con in item)
                    Console.WriteLine(con.ToString());

            Console.WriteLine("\nprouping contracts by area:\n");
            var v9 = bl.GroupContractByLocation();
            foreach (IGrouping<Location, Contract> item in v9)
                foreach (Contract con in item)
                    Console.WriteLine(con.ToString());


            Console.ReadKey();





        }
    }
}
*/