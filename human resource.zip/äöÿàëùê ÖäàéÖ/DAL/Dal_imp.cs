﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;
using DS;


namespace DAL
{
    public class Dal_imp : Idal
    {

        static Random r = new Random();

        #region Specialization
        /// <summary>
        /// a function that throw exception  if it needed(when we add or update a Specialization)
        /// </summary>
        /// <param name="mySpecialization">specialization for adding or update</param>
        /// <param name="exc">boolian value. true- if there is exception,otherwise-false</param>
        void ExceptionForAddOrUpdateSpecialization(Specialization mySpecialization, ref bool exc)
        {
            if (mySpecialization.MinimumRate <= 0)
            { exc = true; throw new Exception("invalid minimum rate"); }
            if (mySpecialization.MaximumRate <= 0)
            { exc = true; throw new Exception("invalid maximum rate"); }

            if (mySpecialization.MinimumRate > mySpecialization.MaximumRate)
            { exc = true; throw new Exception("maximum rate must be bigger than minimum rate"); }
            
        }
        public void AddSpecialization(Specialization mySpecialization)
        {
            bool exc = false;
            Specialization spp = GetAllSpecialization().FirstOrDefault(sc => sc.Domain_Name == mySpecialization.Domain_Name && sc.SpecializationName == mySpecialization.SpecializationName);
            if (spp != null)
                throw new Exception("specialization already exists");
            Specialization sp = GetSpecialization(mySpecialization.NumSpecialization);
            if (sp != null)
                throw new Exception("specialization with the same number already exists");


            ExceptionForAddOrUpdateSpecialization(mySpecialization, ref exc);
            if (exc)
                return;

            mySpecialization.NumSpecialization = Specialization.specialCounter;
            Specialization.specialCounter++;
            DataSource.SpecializationList.Add(mySpecialization);
        }
        public bool DeleteSpecializationNum(int numSpecialization)
        {
            Specialization sp = GetSpecialization(numSpecialization);
            if (sp == null)
                throw new Exception("specialization with the same number not found");
            if (GetAllEmployee(em => em.SpecializationIdentify == numSpecialization).Any())
                throw new Exception("the specialization is used by some employees");

            return DataSource.SpecializationList.Remove(sp);
        }

        public void UpdateSpecialization(Specialization mySpecialization)
        {
            bool exc = false;
            int index = DataSource.SpecializationList.FindIndex(sp => sp.NumSpecialization == mySpecialization.NumSpecialization);
            if (index == -1)
                throw new Exception("specialization with the same number not found");
            
            ExceptionForAddOrUpdateSpecialization(mySpecialization, ref exc);
            if (exc)
                return;
            DataSource.SpecializationList[index] = mySpecialization;
        }

        public Specialization GetSpecialization(int myNumSpecialization)
        {
            return DataSource.SpecializationList.FirstOrDefault(sp => sp.NumSpecialization == myNumSpecialization);
        }

        public IEnumerable<Specialization> GetAllSpecialization(Func<Specialization, bool> predicat = null)
        {
            if (predicat == null)
                return DataSource.SpecializationList.AsEnumerable();
            return DataSource.SpecializationList.Where(predicat);
        }
        #endregion


        #region Employee
        void ExceptionForAddOrUpdateEmployee(Employee myEmployee, ref bool exc)
        {
            if (myEmployee.Id == "0")
            { exc = true; throw new Exception("employee with id=0 can't be"); }
            for (int i = 0; i < myEmployee.Id.Length; i++)
                if (!(myEmployee.Id[i] >= '0' && myEmployee.Id[i] <= '9'))
                { exc = true; throw new Exception("id must consists of digits"); }
            for (int i = 0; i < myEmployee.PhoneNumber.Length; i++)
                if (!(myEmployee.PhoneNumber[i] >= '0' && myEmployee.PhoneNumber[i] <= '9'))
                { exc = true; throw new Exception("phone number must consists of digits"); }
            if (myEmployee.YearsOfExperience < 0)
            { exc = true; throw new Exception("number years  of experience must be positive"); }
        }
        public void AddEmployee(Employee myEmployee)
        {
            bool exc = false;
            Employee em = GetEmployee(myEmployee.Id);
            if (em != null)
                throw new Exception("employee with the same id already exists");
            ExceptionForAddOrUpdateEmployee(myEmployee, ref exc);
            if (exc)
                return;
            DataSource.EmployeeList.Add(myEmployee);
        }

        public bool DeleteEmployee(string myId)
        {
            Employee em = GetEmployee(myId);
            if (em == null)
                throw new Exception("Employee with the same id not found");
            if (GetAllContract(emp => emp.EmployeeId == myId).Any())
                throw new Exception("the employee is a part of a contract");

            return DataSource.EmployeeList.Remove(em);
        }
        public void UpdateEmployee(Employee myEmployee)
        {
            bool exc = false;
            int index = DataSource.EmployeeList.FindIndex(em => em.Id == myEmployee.Id);
            if (index == -1)
                throw new Exception("Employee with the same id not found");
            ExceptionForAddOrUpdateEmployee(myEmployee, ref exc);
            if (exc)
                return;
            DataSource.EmployeeList[index] = myEmployee;
        }
        public Employee GetEmployee(string myId)
        {
            return DataSource.EmployeeList.FirstOrDefault(em => em.Id == myId);

        }

        public IEnumerable<Employee> GetAllEmployee(Func<Employee, bool> predicat = null)
        {
            if (predicat == null)
                return DataSource.EmployeeList.AsEnumerable();
            return DataSource.EmployeeList.Where(predicat);
        }
        #endregion


        #region Employer
        public void AddEmployer(Employer myEmployer)
        {
            int i = 0;
            Employer em = GetEmployer(myEmployer.NumCompany);
            if (em != null)
                throw new Exception("employer with the same company's number already exists");
            for (i = 0; i < myEmployer.NumCompany.Length; i++)
                if (!(myEmployer.NumCompany[i] >= '0' && myEmployer.NumCompany[i] <= '9'))
                    throw new Exception("company number must consists of digits");
            if (myEmployer.NumCompany == "0")
            { throw new Exception("company with number=0 can't be"); }
            //if (myEmployer.IsPrivate && myEmployer.NumCompany == 0)
            //    throw new Exception("incorrect id");
            //if (!myEmployer.IsPrivate && myEmployer.NumCompany == 0)
            //{
            //    bool flag = true;//the code isnt good.
            //    while (flag)
            //    {
            //        i = r.Next(1, 1000000);
            //        myEmployer.NumCompany = i;
            //        if (GetEmployer(myEmployer.NumCompany) == null)
            //            flag = false;
            //    }
            //}
            for (int j = 0; j < myEmployer.PhoneNumber.Length; j++)
                if (!(myEmployer.PhoneNumber[j] >= '0' && myEmployer.PhoneNumber[j] <= '9'))
              throw new Exception("phone number must consists of digits"); 
            DataSource.EmployerList.Add(myEmployer);
            //if (myEmployer.NumCompany == i)
            //    throw new Exception("company number changed to" + myEmployer.NumCompany);
        }
        public bool DeleteEmployer(string myNumCompany)
        {
            Employer em = GetEmployer(myNumCompany);
            if (em == null)
                throw new Exception("Employer with the same company's number not found");
            if (GetAllContract(emp => emp.EmployerNum == myNumCompany).Any())
                throw new Exception("the employer is a part of a contract");

            return DataSource.EmployerList.Remove(em);
        }
        public void UpdateEmployer(Employer myEmployer)
        {
            int index = DataSource.EmployerList.FindIndex(em => em.NumCompany == myEmployer.NumCompany);
            if (index == -1)
                throw new Exception("Employer with the same company's number not found");
            for (int i = 0; i < myEmployer.PhoneNumber.Length; i++)
                if (!(myEmployer.PhoneNumber[i] >= '0' && myEmployer.PhoneNumber[i] <= '9'))
                    throw new Exception("phone number must consists of digits");
            DataSource.EmployerList[index] = myEmployer;
        }
        public Employer GetEmployer(string myNumCompany)
        {
            return DataSource.EmployerList.FirstOrDefault(em => em.NumCompany == myNumCompany);

        }
        public IEnumerable<Employer> GetAllEmployer(Func<Employer, bool> predicat = null)

        {
            if (predicat == null)
                return DataSource.EmployerList.AsEnumerable();
            return DataSource.EmployerList.Where(predicat);
        }
        #endregion


        #region Contract
        public void AddContract(Contract myContract)
        {
            //Contract c = GetContract(myContract.ContractNum);
            //if (c != null)
            //    throw new Exception("contract with the same number already exists");
            if(myContract.HourDeal<=0)
                throw new Exception("deal's hour must be above 0");
            if (myContract.GrossSalaryPerHour<= 0)
                throw new Exception("gross salary must be above 0");
            myContract.ContractNum = Contract.countContract;
            Contract.countContract++;
            DataSource.ContractList.Add(myContract);
        }
        public bool DeleteContract(int myContractNum)
        {
            Contract c = GetContract(myContractNum);
            if (c == null)
                throw new Exception("contract with the same number not found");
            return DataSource.ContractList.Remove(c);
        }
        public void UpdateContract(Contract myContract)
        {
            int index = DataSource.ContractList.FindIndex(c => c.ContractNum == myContract.ContractNum);
            if (index == -1)
                throw new Exception("contract with the same number not found");
            if (myContract.HourDeal <= 0)
                throw new Exception("deal's hour must be above 0");
            if (myContract.GrossSalaryPerHour <= 0)
                throw new Exception("gross salary must be above 0");
            DataSource.ContractList[index] = myContract;
        }
        public Contract GetContract(int myContractNum)
        {
            return DataSource.ContractList.FirstOrDefault(c => c.ContractNum == myContractNum);

        }

        public IEnumerable<Contract> GetAllContract(Func<Contract, bool> predicat = null)
        {
            if (predicat == null)
                return DataSource.ContractList.AsEnumerable();
            return DataSource.ContractList.Where(predicat);
        }
        #endregion
        /// <summary>
        /// retrun list of 5 bank branches
        /// </summary>
        /// <returns>list of branch</returns>
        public List<Branch> GetAllBranches()
        {
            List<Branch> L = new List<Branch>()
            {
                new Branch { BankNumber="333",BankName="leumi",NumBankBranch="33",BankAddress="11",BankCity="Jerusalem"},
                new Branch { BankNumber="333",BankName="leumi",NumBankBranch="89",BankAddress="15",BankCity="Tel-Aviv"},
                new Branch { BankNumber="99",BankName="poalim",NumBankBranch="798",BankAddress="17",BankCity="Jerusalem"},
                new Branch { BankNumber="99",BankName="poalim",NumBankBranch="663",BankAddress="89",BankCity="Eilat"},
                new Branch { BankNumber="101",BankName="yahav",NumBankBranch="908",BankAddress="90",BankCity="Jerusalem"},
            };


            return L;
        }
    }
}
