﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;
namespace DS
{
    public class DataSource
    {
        public static List<Employee> EmployeeList = new List<Employee>();
        public static List<Employer> EmployerList = new List<Employer>();
        public static List<Contract> ContractList = new List<Contract>();
        public static List<Specialization> SpecializationList = new List<Specialization>();

    }
}
