﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;

namespace BL
{
    public interface IBL
    {
        
        #region Specialization
        /// <summary>
        /// add new Specialization to SpecializationList
        /// </summary>
        /// <param name="mySpecialization">new Specialization for adding</param>
        void AddSpecialization(Specialization mySpecialization);

        /// <summary>
        /// delete Specialization from SpecializationList
        /// </summary>
        /// <param name="numSpecialization">number of Specialization</param>
        /// <returns>true if Specialization is successfully removed otherwise, false</returns>
        bool DeleteSpecializationNum(int numSpecialization);

        /// <summary>
        /// update a Specialization that already exist in SpecializationList
        /// </summary>
        /// <param name="mySpecialization">Specialization with the deatails for update</param>
        void UpdateSpecialization(Specialization mySpecialization);

        /// <summary>
        /// get specific Specialization from SpecializationList
        /// </summary>
        /// <param name="numSpecialization">number of Specialization</param>
        /// <returns>the request Specialization</returns>
        Specialization GetSpecialization(int numSpecialization);

        /// <summary>
        /// get Specializations from the SpecializationList that suitable for specific Condition
        /// </summary>
        /// <param name="predicat">the Condition(its a delegate)</param>
        /// <returns>return some of the SpecializationList(as a list) or the whole list </returns>
        IEnumerable<Specialization> GetAllSpecialization(Func<Specialization, bool> predicat = null);
        #endregion

        
        #region Employee
        /// <summary>
        /// add new Employee to EmployeeList
        /// </summary>
        /// <param name="myEmployee"> a new employee for adding</param>
        void AddEmployee(Employee myEmployee);

        /// <summary>
        /// delete employee from EmployeeList
        /// </summary>
        /// <param name="myId">ID of the employee for removing</param>
        /// <returns>true if employee is successfully removed otherwise, false</returns>
        bool DeleteEmployee(string myId);

        /// <summary>
        /// update a employee that already exist in EmployeeList
        /// </summary>
        /// <param name="myEmployee">employee with the deatails for update</param>
        void UpdateEmployee(Employee myEmployee);

        /// <summary>
        /// get specific Employee from EmployeeList
        /// </summary>
        /// <param name="myId">ID of the employee for getting</param>
        /// <returns>the request employee</returns>
        Employee GetEmployee(string myId);

        /// <summary>
        /// get employees from the EmployeeList that suitable for specific Condition
        /// </summary>
        /// <param name="predicat">the Condition(its a delegate)</param>
        /// <returns>return some of the EmployeeList(as a list) or the whole list </returns>
        IEnumerable<Employee> GetAllEmployee(Func<Employee, bool> predicat = null);
        #endregion

        
        #region Employer
        /// <summary>
        /// add new Employer to EmployerList
        /// </summary>
        /// <param name="myEmployer"> a new employer for adding</param>
        void AddEmployer(Employer myEmployer);

        /// <summary>
        /// delete employer from EmployerList
        /// </summary>
        /// <param name="myNumCompany"> number of company for removing</param>
        /// <returns>true if employer is successfully removed otherwise, false</returns>
        bool DeleteEmployer(string myNumCompany);

        /// <summary>
        ///  update a employer that already exist in EmployerList
        /// </summary>
        /// <param name="myEmployer">employer with the deatails for update</param>
        void UpdateEmployer(Employer myEmployer);

        /// <summary>
        /// get specific Employer from EmployerList
        /// </summary>
        /// <param name="myNumCompany">number of Employer</param>
        /// <returns>the request employer</returns>
        Employer GetEmployer(string myNumCompany);

        /// <summary>
        /// get employers from the EmployerList that suitable for specific Condition
        /// </summary>
        /// <param name="predicat">the Condition(its a delegate)</param>
        /// <returns>return some of the EmployerList(as a list) or the whole list</returns>
        IEnumerable<Employer> GetAllEmployer(Func<Employer, bool> predicat = null);
        #endregion

        
        #region Contract
        /// <summary>
        /// add new contract to ContractList
        /// </summary>
        /// <param name="myContract">the new contract for adding</param>
        void AddContract(Contract myContract);

        /// <summary>
        /// delete contract from ContractList
        /// </summary>
        /// <param name="myContractNum">num of the contract for removing</param>
        /// <returns>true if contract is successfully removed otherwise, false</returns>
        bool DeleteContract(int myContractNum);

        /// <summary>
        /// update a contract that already exist in ContractList
        /// </summary>
        /// <param name="myContract">contract with the deatails for update</param>
        void UpdateContract(Contract myContract);

        /// <summary>
        /// get specific contract from ContractList
        /// </summary>
        /// <param name="myContractNum"> number of contract</param>
        /// <returns>the request contract</returns>
        Contract GetContract(int myContractNum);

        /// <summary>
        /// get contracts from the ContractList that suitable for specific Condition
        /// </summary>
        /// <param name="predicat">the Condition(its a delegate)</param>
        /// <returns>return some of the ContractList(as a list) or the whole list</returns>
        IEnumerable<Contract> GetAllContract(Func<Contract, bool> predicat = null);

        /// <summary>
        /// return the number of contracts that implement  specific Condition
        /// </summary>
        /// <param name="predicat">the Condition(its a delegate)</param>
        /// <returns>the number of contacts from the ContractList that implement the predicat </returns>
        int NumOfContract(Func<Contract, bool> predicat = null);
        #endregion
        
        #region IGrouping
        /// <summary>
        /// return collection of contracts  that dividing for groups by Specialization(appear in every contract)
        /// </summary>
        /// <param name="order">if every group has to be sorted</param>
        /// <returns>collection of (sorted/not sorted) groups of contracts</returns>
        IEnumerable<IGrouping<int, Contract>> GroupContractBySpecialization(bool order = false);

        /// <summary>
        /// return collection of contracts  that dividing for groups by Location(appear in every contract)
        /// </summary>
        /// <param name="order">if every group has to be sorted</param>
        /// <returns>collection of (sorted/not sorted) groups of contracts</returns>
        IEnumerable<IGrouping<Location, Contract>> GroupContractByLocation(bool order = false);

        /// <summary>
        /// return collection of  Profits that dividing for groups by Time
        /// </summary>
        /// <param name="sorted">if every group has to be sorted</param>
        /// <returns>collection of (sorted/not sorted) groups of Profits</returns>
        IEnumerable<IGrouping<int, double>> GroupingProfitbyTime(bool sorted = false);
        #endregion
        IEnumerable<Employee> EmployeesOfSpesificEmployer(Employer emp);
        IEnumerable<Employee> MostexperiencedEmployeeOfSpecialization(Specialization sp);
        Employee EmployeeWithMaxSalary(Employer emp);
        IEnumerable<Contract> signContracts();
    }
}
