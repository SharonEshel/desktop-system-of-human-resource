﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;


namespace BL
{
    public class BL : IBL
    {
        DAL.Idal dal;

        protected BL()
        {
            dal = DAL.FactoryDal.GetDal();
            // initList();
        }

        
        protected static BL instance = null;
        public static BL GetInstance()
        {
            if (instance == null)
                instance = new BL();
            return instance;
        }

        public static IEnumerable<IGrouping<string, ATM>> GetAllAtmGroupByCity()
        {
            return DAL.Dal_XML_imp.GetAllAtmGroupByCity();
        }
        public static IEnumerable<IGrouping<string, IGrouping<string, ATM>>> GetAllAtmGroupByBankAndCity()
        {
            return DAL.Dal_XML_imp.GetAllAtmGroupByBankAndCity();
        }

        #region Specialization
        public void AddSpecialization(Specialization mySpecialization)
        {
            dal.AddSpecialization(mySpecialization);
        }
        public bool DeleteSpecializationNum(int numSpecialization)
        {
            return dal.DeleteSpecializationNum(numSpecialization);
        }
        public void UpdateSpecialization(Specialization mySpecialization)
        {
            dal.UpdateSpecialization(mySpecialization);
        }
        public Specialization GetSpecialization(int numSpecialization)
        {
            return dal.GetSpecialization(numSpecialization);

        }
        public IEnumerable<Specialization> GetAllSpecialization(Func<Specialization, bool> predicat = null)
        {
            return dal.GetAllSpecialization(predicat);

        }
        #endregion

        
        #region Employee
        /// <summary>
        /// a function that throw exception  if it needed(when we add or update an Employee)
        /// </summary>
        /// <param name="myEmployee">the employee for adding or updating</param>
        /// <param name="exc">boolian value. true- if there is exception,otherwise-false</param>
        void ExceptionForAddOrUpdateEmployee(Employee myEmployee,ref bool exc)
        {
            
            if ((DateTime.Today.Year - myEmployee.BirthDate.Year) < 18)//אם הפרש השנים קטן מ18
            {
                exc = true;
                throw new Exception("employee's age must be above 18");
                
            }
            if ((DateTime.Today.Year - myEmployee.BirthDate.Year == 18))//אם ההפרש שווה 18
            {
                if ((DateTime.Today.Month < myEmployee.BirthDate.Month))//אם החודש העכשווי קטן מחודש הלידה
                { exc = true; throw new Exception("employee's age must be above 18");  }
                if ((DateTime.Today.Month == myEmployee.BirthDate.Month))//אם החודש העכשווי שווה לחודש הלידה
                {
                    if ((DateTime.Today.Day < myEmployee.BirthDate.Day))//אם היום העכשוי קטן מיום הלידה
                    { exc = true; throw new Exception("employee's age must be above 18"); }
                }
            }
        }


        public void AddEmployee(Employee myEmployee)
        {
            bool exc = false;
            ExceptionForAddOrUpdateEmployee(myEmployee, ref exc);
            if(exc)
                return;
            dal.AddEmployee(myEmployee);

        }
        public bool DeleteEmployee(string myId)
        {
            return dal.DeleteEmployee(myId);
        }
        public void UpdateEmployee(Employee myEmployee)
        {
            bool exc = false;
            ExceptionForAddOrUpdateEmployee(myEmployee, ref exc);
            if (exc)
                return;
            dal.UpdateEmployee(myEmployee);

        }
        public Employee GetEmployee(string myId)
        {
            return dal.GetEmployee(myId);
        }
        public IEnumerable<Employee> GetAllEmployee(Func<Employee, bool> predicat = null)
        {
            return dal.GetAllEmployee(predicat);
        }
        #endregion
        
        #region Employer
        public void AddEmployer(Employer myEmployer)
        {
            dal.AddEmployer(myEmployer);
        }
        public bool DeleteEmployer(string myNumCompany)
        {
            return dal.DeleteEmployer(myNumCompany);
        }
        public void UpdateEmployer(Employer myEmployer)
        {
            dal.UpdateEmployer(myEmployer);
        }
        public Employer GetEmployer(string myNumCompany)
        {
            return dal.GetEmployer(myNumCompany);
        }
        public IEnumerable<Employer> GetAllEmployer(Func<Employer, bool> predicat = null)
        {
            return dal.GetAllEmployer(predicat);
        }
        #endregion
        #region contract

        /// <summary>
        /// a function that throw exception  if it needed(when we add or update contract)
        /// </summary>
        /// <param name="myContract">the Contract for adding or updating</param>
        /// <param name="excp">boolian value. true- if there is exception,otherwise-false</param>
        void ExceptionForAddOrUpdateContract(Contract myContract, ref bool excp)
        {
            if (GetEmployee(myContract.EmployeeId) == null)
            { excp = true; throw new Exception("the employee isn't exist in the system"); }
            if (GetEmployer(myContract.EmployerNum) == null)
            { excp = true; throw new Exception("the employer isn't exist in the system");  }
                //check that the employer is bigger than a 1 year if it's signed
                if (myContract.SigningDeal)
            {
                if ((DateTime.Today.Year - GetEmployer(myContract.EmployerNum).EstablishmentDate.Year) < 1)//אם הפרש השנים קטן מ1
                { excp = true; throw new Exception("a contract can be signed only if the company exist above a year"); }
                    if ((DateTime.Today.Year - GetEmployer(myContract.EmployerNum).EstablishmentDate.Year) == 1)//אם ההפרש שווה 1
                {
                    if ((DateTime.Today.Month < GetEmployer(myContract.EmployerNum).EstablishmentDate.Month))//אם החודש העכשווי קטן מחודש הלידה
                    { excp = true; throw new Exception("a contract can be signed only if the company exist above a year");  }
                        if ((DateTime.Today.Month == GetEmployer(myContract.EmployerNum).EstablishmentDate.Month))//אם החודש העכשווי שווה לחודש הלידה
                    {
                        if ((DateTime.Today.Day < GetEmployer(myContract.EmployerNum).EstablishmentDate.Day))//אם היום העכשוי קטן מיום הלידה
                        { excp = true; throw new Exception("a contract can be signed only if the company exist above a year");  }
                        }
                }
            }
            //שכר קטן מהמינימום או גדול מהמקסימום
            if (myContract.GrossSalaryPerHour < GetSpecialization(GetEmployee(myContract.EmployeeId).SpecializationIdentify).MinimumRate || myContract.GrossSalaryPerHour > GetSpecialization(GetEmployee(myContract.EmployeeId).SpecializationIdentify).MaximumRate)
            { excp = true; throw new Exception("the gross salary must be suitable to the specialization");  }

            }

        public void AddContract(Contract myContract)
        {


            
            bool excp = false;
            ExceptionForAddOrUpdateContract(myContract, ref excp);
            if (excp)
                return;

            myContract.NetoSalaryPerHour = myContract.GrossSalaryPerHour * (1 - 0.1 / discount(myContract));

            dal.AddContract(myContract);
            //dal.UpdateContract(myContract);//in order to correct the neto salary

        }

        /// <summary>
        /// help function for calculate discount for commission(עמלה)
        /// </summary>
        /// <param name="myContract">the Contract that its commission is calculated</param>
        /// <returns>the discount of commission(if there is a discount)</returns>
        int discount(Contract myContract)
        {
            //return NumOfContract(con => con.EmployerNum == myContract.EmployerNum) * NumOfContract(con => con.EmployeeId == myContract.EmployeeId);
            int discount_According_Employer = NumOfContract(con => con.EmployerNum == myContract.EmployerNum);
            int discount_According_Employee = NumOfContract(con => con.EmployeeId == myContract.EmployeeId);
            if (discount_According_Employer > 0 && discount_According_Employee > 0)
                return discount_According_Employer * discount_According_Employee;
            else if (discount_According_Employer > 0)
                return discount_According_Employer;
            else if (discount_According_Employee > 0)
                return discount_According_Employee;
            else return 1;
        }



        public bool DeleteContract(int myContractNum)
        {
            return dal.DeleteContract(myContractNum);
        }
        public void UpdateContract(Contract myContract)
        {
            
            bool excp = false;
            ExceptionForAddOrUpdateContract(myContract, ref excp);
            if (excp)
                return;
            myContract.NetoSalaryPerHour = myContract.GrossSalaryPerHour * (1 - 0.1 / discount(myContract));
            dal.UpdateContract(myContract);
        }
        public Contract GetContract(int myContractNum)
        {
            return dal.GetContract(myContractNum);
        }
        public IEnumerable<Contract> GetAllContract(Func<Contract, bool> predicat = null)
        {
            return dal.GetAllContract(predicat);
        }


        public int NumOfContract(Func<Contract, bool> predicat = null)
        {
            return GetAllContract().Where(predicat).Count();
        }
        #endregion
        #region IGrouping

        
        public IEnumerable<IGrouping<int, Contract>> GroupContractBySpecialization(bool order = false)
        {
            IEnumerable<IGrouping<int, Contract>> v;
            if (order)
                v = from c in dal.GetAllContract()
                    orderby c.ContractNum
                    group c by GetEmployee(c.EmployeeId).SpecializationIdentify;
            else
                v = from c in dal.GetAllContract()
                    group c by GetEmployee(c.EmployeeId).SpecializationIdentify;

            return v;


            //var groups = DataSource.ContractList.GroupBy(con => GetEmployee(con.EmployeeId).SpecializationIdentify);
            //if (order == true)
            //{
            //    foreach (IGrouping<int, Contract> group in groups) 
            //        {
            //        group.OrderBy(con => con.ContractNum);
            //        return groups;
            //    }
            //}
        }

        public IEnumerable<IGrouping<int, double>> GroupingProfitbyTime(bool sorted = false)
        {
            IEnumerable<IGrouping<int, double>> v;
            if (sorted)
                v = from c in dal.GetAllContract()
                    orderby c.ContractEndDate
                    let pro = c.HourDeal * (c.GrossSalaryPerHour - c.NetoSalaryPerHour)
                    group pro by c.ContractEndDate.Year into g
                    group g.Sum() by g.Key;

            else
                v = from c in dal.GetAllContract()
                    let pro = c.HourDeal * (c.GrossSalaryPerHour - c.NetoSalaryPerHour)
                    group pro by c.ContractEndDate.Year into g
                    group g.Sum() by g.Key;

            return v;
        }

        public IEnumerable<IGrouping<Location, Contract>> GroupContractByLocation(bool order = false)
        {
            IEnumerable<IGrouping<Location, Contract>> v;
            if (order)
                v = from c in dal.GetAllContract()
                    orderby c.ContractNum
                    group c by GetEmployer(c.EmployerNum).EmployerLocation;
            else
                v = from c in dal.GetAllContract()
                    group c by GetEmployer(c.EmployerNum).EmployerLocation;

            return v;
        }

        #endregion
        #region additional functions

       

        /// <summary>
        /// return the employee with the bigger salary among the rest employees of a specific employer
        /// </summary>
        /// <param name="emp">specific employer</param>
        /// <returns>employee</returns>
        public Employee EmployeeWithMaxSalary(Employer emp)//מחזירה את המועסק עם המשכורת הגדולה מבין כל שאר המועסקים של מעסיק ספציפי
        {

            double maxSalary = SignContractsOfSpesificEmployer(emp).Select(c => c.HourDeal * c.NetoSalaryPerHour).Max();//select  עושה המרה
            return GetEmployee(SignContractsOfSpesificEmployer(emp).FirstOrDefault(c => c.HourDeal * c.NetoSalaryPerHour == maxSalary).EmployeeId);

        }

        /// <summary>
        /// return list of signed contracts
        /// </summary>
        /// <returns>list of contracts</returns>
        public IEnumerable<Contract> signContracts()//מחזירה רשימה של חוזים חתומים
        {
            IEnumerable<Contract> con = GetAllContract().Where(c => c.SigningDeal);
            if (con == null)
                throw new Exception("there isn't signed contract");
            return con;
        }

        /// <summary>
        /// return list of contracts which belong to specific employer
        /// </summary>
        /// <param name="emp">employer</param>
        /// <returns>list of contracts</returns>
        public IEnumerable<Contract> SignContractsOfSpesificEmployer(Employer emp)//מחזירה רשימה של החוזים בהם מופיע מעסיק מסויים
        {
            Employer em = GetEmployer(emp.NumCompany);
            if (em == null)
                throw new Exception("employer isn't exists");
            var v = signContracts().Where(c => c.EmployerNum == emp.NumCompany);
            if (v == null)
                throw new Exception("employer isn't exists in sign contract");
            return v;
        }

        /// <summary>
        /// return list of employees that are employed by specific employer
        /// </summary>
        /// <param name="emp">specific employer</param>
        /// <returns>list of employees</returns>
        public IEnumerable<Employee> EmployeesOfSpesificEmployer(Employer emp)//מחזירה רשימה של כל המועסקים ע"י מעסיק ספציפי
        {
            return SignContractsOfSpesificEmployer(emp).Select(con => GetEmployee(con.EmployeeId));
        }


        /// <summary>
        /// return list of signed contracts that belong to specific employee
        /// </summary>
        /// <param name="em">specific employee</param>
        /// <returns>list of contacts</returns>
        public IEnumerable<Contract> SignContractsOfSpesificEmployee(Employee em)
        {
            Employee emm = GetEmployee(em.Id);
            if (emm == null)
                throw new Exception("employee isn't exists");
            var v = signContracts().Where(c => c.EmployeeId == em.Id);
            if (v == null)
                throw new Exception("employee isn't exists in sign contract");
            return v;
        }
        /// <summary>
        /// return the total salary (per month) of specific employee(if he has some employers)
        /// </summary>
        /// <param name="em"></param>
        /// <returns></returns>
        public double EmployeeSalaryPerMonth (Employee em)
        {
            return 4*(SignContractsOfSpesificEmployee(em).Select(c => c.HourDeal * c.NetoSalaryPerHour).Sum());
        }
        /// <summary>
        /// gets a specialization and return the employee with the most experience in this specialization
        /// </summary>
        /// <param name="sp">specialization </param>
        /// <returns>employee wuth the most experience</returns>
        public IEnumerable<Employee> MostexperiencedEmployeeOfSpecialization(Specialization sp)
        {
            Specialization spc = GetSpecialization(sp.NumSpecialization);
            if (spc == null)
                throw new Exception("the specialization isn't exists");
            int mostYearsOfExperience= GetAllEmployee().Where(emp => emp.SpecializationIdentify == sp.NumSpecialization).Select(emp => emp.YearsOfExperience).Max();
            return GetAllEmployee().Where(emp => emp.SpecializationIdentify == sp.NumSpecialization && emp.YearsOfExperience == mostYearsOfExperience);
            
        }
        /// <summary>
        /// return collection of employees of spcific area with the same specialization
        /// </summary>
        /// <param name="sp">specialization</param>
        /// <param name="lc">location</param>
        /// <returns>collection of employees</returns>
        public IEnumerable<Employee> Employees_Of_Specific_Area_With_Specific_Specialization(Specialization sp,Location lc)
        {
            Specialization spc = GetSpecialization(sp.NumSpecialization);
            if (spc == null)
                throw new Exception("the specialization isn't exists");
            return GetAllEmployee().Where(emp => emp.SpecializationIdentify == sp.NumSpecialization && emp.EmployeeLocation == lc);
        }
        #endregion
    }
}
